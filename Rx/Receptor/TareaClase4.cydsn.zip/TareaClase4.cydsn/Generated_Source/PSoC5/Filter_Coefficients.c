#include "Filter.h"
#include "Filter_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is FIR
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelAFirCoefficients Filter_ChannelAFirCoefficients

/* Number of FIR filter taps are: 15 */

const uint8 CYCODE Filter_ChannelAFirCoefficients[Filter_FIR_A_SIZE] = 
{
 0x31u, 0x05u, 0x00u, 0x00u, /* Tap(0), 0.000158429145812988 */

 0xD2u, 0x19u, 0x00u, 0x00u, /* Tap(1), 0.000787973403930664 */

 0x2Fu, 0x4Du, 0x00u, 0x00u, /* Tap(2), 0.00235545635223389 */

 0xC1u, 0xA8u, 0x00u, 0x00u, /* Tap(3), 0.0051499605178833 */

 0xC4u, 0x27u, 0x01u, 0x00u, /* Tap(4), 0.00902605056762695 */

 0x97u, 0xB0u, 0x01u, 0x00u, /* Tap(5), 0.0132015943527222 */

 0x70u, 0x1Bu, 0x02u, 0x00u, /* Tap(6), 0.0164623260498047 */

 0xF3u, 0x43u, 0x02u, 0x00u, /* Tap(7), 0.0176986455917358 */

 0x70u, 0x1Bu, 0x02u, 0x00u, /* Tap(8), 0.0164623260498047 */

 0x97u, 0xB0u, 0x01u, 0x00u, /* Tap(9), 0.0132015943527222 */

 0xC4u, 0x27u, 0x01u, 0x00u, /* Tap(10), 0.00902605056762695 */

 0xC1u, 0xA8u, 0x00u, 0x00u, /* Tap(11), 0.0051499605178833 */

 0x2Fu, 0x4Du, 0x00u, 0x00u, /* Tap(12), 0.00235545635223389 */

 0xD2u, 0x19u, 0x00u, 0x00u, /* Tap(13), 0.000787973403930664 */

 0x31u, 0x05u, 0x00u, 0x00u, /* Tap(14), 0.000158429145812988 */
};

